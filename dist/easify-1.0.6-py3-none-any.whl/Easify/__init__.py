# Easify/__init__.py

from .main import ass1, ass2, ass3, ass4, ass5, ass6, ass7, info
