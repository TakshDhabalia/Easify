# Easify# Preprocessing Printer

This package prints ready-to-use Python code for data preprocessing tasks such as handling missing values, duplicates, encoding, normalization, and visualization.

## Installation

```bash
pip install preprocessing_printer
